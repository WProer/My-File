<template>
	<view class="discuss">
		<discuss-content></discuss-content>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style lang="scss">
	page {
		height: 100%;
		display: flex;
		// background-color: $base-color;
	}
	
	.discuss{
		width: 100%;
		height: 100%;
		// overflow: hidden;
		box-sizing: border-box;
	}
</style>
