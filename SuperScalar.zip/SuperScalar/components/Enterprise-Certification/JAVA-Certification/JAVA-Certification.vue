<template>
	<view class="JAVA-Certification">
		<view class="JAVA-Certification-item">
			<scroll-view scroll-y="true">
				<view>
					<uni-collapse>
						<uni-collapse-item v-for="(item,index) in list" :key="index" :title="item">
							<view class="JAVA-Certification_Collapse" style="padding: 0px 15px;">
								<Progress-Area></Progress-Area>
							</view>
						</uni-collapse-item>
					</uni-collapse>
				</view>
			</scroll-view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list:['SCJP和SCJD',"SCEA"]
			}
		},
		methods: {

		}
	}
</script>

<style lang="scss">
	.JAVA-Certification {
		margin-top: 10px;
		overflow: hidden;
		box-sizing: border-box;

		.JAVA-Certification-item {
			box-sizing: border-box;
			overflow: hidden;

			.JAVA-Certification_Collapse {
				height: 65px;
				overflow: hidden;
				box-sizing: border-box;
			}
		}
	}
</style>
