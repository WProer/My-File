<template>
	<view class="VUEFamework-Content">
		<text>共推荐到<text>0</text>条结果</text>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style lang="scss">
	.VUEFamework-Content{
		margin: 15px 0px;
		font-size: 18px;
		
		text{
			color: $base-color;
			text{
				color: red;
			}
		}
	}
</style>
